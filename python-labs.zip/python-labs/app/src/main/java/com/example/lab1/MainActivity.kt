package com.example.lab1

import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editText = findViewById<EditText>(R.id.editText)
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroup)
        val buttonOk = findViewById<Button>(R.id.buttonOk)
        val buttonCancel = findViewById<Button>(R.id.buttonCancel)
        val resultText = findViewById<TextView>(R.id.resultText)

        buttonOk.setOnClickListener {
            val text = editText.text.toString()
            val selectedFont = when (radioGroup.checkedRadioButtonId) {
                R.id.radioButtonBold -> Typeface.BOLD
                R.id.radioButtonItalic -> Typeface.ITALIC
                else -> Typeface.NORMAL
            }
            if (text.isEmpty() || radioGroup.checkedRadioButtonId == -1) {
                val dialog = AlertDialog.Builder(this)
                    .setTitle("Error")
                    .setMessage("Please input all nessesory data.")
                    .setPositiveButton("OK") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .create()
                dialog.show()
            } else {
            resultText.text = text
            resultText.setTypeface(null, selectedFont)
        }
        }
        buttonCancel.setOnClickListener {
            editText.text.clear()
            resultText.text = ""
        }
    }
}